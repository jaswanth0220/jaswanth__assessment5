﻿namespace Assessment5.DTOS
{
    public class PomasterDTO
    {
        public string pono { get; set; }
        public string ITCODE { get; set; }
        public string SuplNo { get; set; }

        public int Quantity { get; set; }
        public DateTime Date { get; set; }

    }
}
