﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assessment5.Entities
{
    public class Pomaster
    {
        [Key]
        [Column(TypeName ="char")]
        [StringLength(4)]
        public string pono {  get; set; }


        public DateTime? date { get; set; }


        [ForeignKey("Item")]
        [Column(TypeName ="char")]
        [StringLength(4)]
        public string ITCODE { get; set; }
        public Item Item { get; set; }

        
        public int Quantity { get; set; }


        [ForeignKey("Supplier")]
        [Column(TypeName ="char")]
        [StringLength(4)]
        public string SuplNo { get; set; }
        public Supplier Supplier { get; set; }
    }
}
