﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assessment5.Migrations
{
    /// <inheritdoc />
    public partial class SupplierMigrations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    Suplno = table.Column<string>(type: "char(4)", nullable: false),
                    SupplName = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false),
                    SupLAddr = table.Column<string>(type: "varchar(40)", maxLength: 40, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.Suplno);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Suppliers");
        }
    }
}
