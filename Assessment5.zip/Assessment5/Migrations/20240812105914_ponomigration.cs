﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assessment5.Migrations
{
    /// <inheritdoc />
    public partial class ponomigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Pomasters",
                columns: table => new
                {
                    pono = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ITCODE = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    SuplNo = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pomasters", x => x.pono);
                    table.ForeignKey(
                        name: "FK_Pomasters_Items_ITCODE",
                        column: x => x.ITCODE,
                        principalTable: "Items",
                        principalColumn: "ITCODE",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Pomasters_Suppliers_SuplNo",
                        column: x => x.SuplNo,
                        principalTable: "Suppliers",
                        principalColumn: "Suplno",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_ITCODE",
                table: "Pomasters",
                column: "ITCODE");

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_SuplNo",
                table: "Pomasters",
                column: "SuplNo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pomasters");
        }
    }
}
