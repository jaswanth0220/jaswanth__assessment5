﻿using Assessment5.Entities;
using Microsoft.EntityFrameworkCore;

namespace Assessment5.Repositories
{
    public class PomasterRepository: IPomasterRepository
    {
        private readonly PODbContext _context;

        public PomasterRepository(PODbContext context)
        {
            _context = context;
        }

        public async Task Add(Pomaster pomaster)
        {
            await _context.Pomasters.AddAsync(pomaster);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string pono)
        {
            var pomaster = await _context.Pomasters.FindAsync(pono);
            _context.Pomasters.Remove(pomaster);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Pomaster>> GetAll()
        {
            return await _context.Pomasters.ToListAsync();
        }

        public async Task<Pomaster> GetByPONO(string pono)
        {
            return await _context.Pomasters.SingleOrDefaultAsync(p => p.pono == pono);
        }

        public async Task Update(Pomaster pomaster)
        {
             _context.Pomasters.Update(pomaster);
            await _context.SaveChangesAsync();
        }
    }
}
