﻿using Assessment5.Entities;
using Microsoft.EntityFrameworkCore;

namespace Assessment5.Repositories
{
    public class ItemRepository: IItemRepository
    {
        private readonly PODbContext _context;
        public ItemRepository(PODbContext context)
        {
            _context = context;
        }

        public async Task Add(Item item)
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string itcode)
        {
            var item = await _context.Items.FindAsync(itcode);
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Item>> GetAll()
        {
            return await _context.Items.ToListAsync();
        }

        public async Task<Item> GetByITCODE(string itcode)
        {
            return await _context.Items.SingleOrDefaultAsync(i => i.ITCODE == itcode);
        }

        public async Task Update(Item item)
        {
            _context.Items.Update(item);
            await _context.SaveChangesAsync();
        }
    }
}
